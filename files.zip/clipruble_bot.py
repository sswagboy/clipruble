# ============================================================
# КЛИПРУБЛЬ — Telegram Bot
# ============================================================
# Установка (одна команда):
#   pip install aiogram
#
# Запуск:
#   python clipruble_bot.py
# ============================================================

import asyncio
import logging
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    WebAppInfo,
    Message
)
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties

# ── НАСТРОЙКИ — вставь сюда свои данные ───────────────────
BOT_TOKEN = "СЮДА_ВСТАВЬ_ТОКЕН_ОТ_BOTFATHER"
APP_URL   = "СЮДА_ВСТАВЬ_ССЫЛКУ_С_VERCEL"
# Пример APP_URL: "https://index-abc123.vercel.app"
# ──────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s"
)
log = logging.getLogger(__name__)

bot = Bot(
    token=BOT_TOKEN,
    default=DefaultBotProperties(parse_mode=ParseMode.MARKDOWN)
)
dp = Dispatcher()


# ── Кнопка открытия Web App ────────────────────────────────
def btn(text="✂️ Открыть КЛИПРУБЛЬ"):
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text=text,
            web_app=WebAppInfo(url=APP_URL)
        )
    ]])


# ── /start ────────────────────────────────────────────────
@dp.message(CommandStart())
async def cmd_start(message: Message):
    name = message.from_user.first_name
    await message.answer(
        f"👋 Привет, *{name}*!\n\n"
        f"Добро пожаловать в *КЛИПРУБЛЬ* ✂️\n\n"
        f"Зарабатывай деньги, нарезая клипы "
        f"популярных блогеров.\n\n"
        f"*Как это работает:*\n"
        f"1️⃣ Выбираешь кампанию блогера\n"
        f"2️⃣ Нарезаешь клип и загружаешь ссылку\n"
        f"3️⃣ Модератор проверяет до 24 часов\n"
        f"4️⃣ Деньги начисляются автоматически 🤖\n\n"
        f"👇 Нажми кнопку чтобы начать",
        reply_markup=btn("🚀 Открыть платформу")
    )


# ── /balance ──────────────────────────────────────────────
@dp.message(Command("balance"))
async def cmd_balance(message: Message):
    name = message.from_user.first_name
    await message.answer(
        f"💰 *Баланс — {name}*\n\n"
        f"┌ Доступно к выводу: *540.30 ₽*\n"
        f"├ Заработано всего: *740.30 ₽*\n"
        f"├ Всего просмотров: *1.8М*\n"
        f"├ Клипов одобрено: *2*\n"
        f"└ На проверке: *1*\n\n"
        f"Минимум для вывода: *100 ₽*\n\n"
        f"👇 Открой приложение чтобы вывести деньги",
        reply_markup=btn("💰 Открыть кошелёк")
    )


# ── /clips ────────────────────────────────────────────────
@dp.message(Command("clips"))
async def cmd_clips(message: Message):
    await message.answer(
        "✂️ *Мои последние клипы*\n\n"
        "1. ✅ *MrBeast — 100 дней под водой*\n"
        "    👁 482к просм. · +144.60 ₽\n\n"
        "2. ⏳ *Лучший момент с MrBeast*\n"
        "    👁 219к просм. · +65.70 ₽\n\n"
        "3. ✅ *MrBeast vs 100 человек*\n"
        "    👁 1.1М просм. · +330.00 ₽\n\n"
        "4. ❌ *Смешной момент — MrBeast*\n"
        "    👁 0 просм. · отклонён\n\n"
        "_Показаны последние 4 клипа_",
        reply_markup=btn("📋 Все клипы")
    )


# ── /campaigns ────────────────────────────────────────────
@dp.message(Command("campaigns"))
async def cmd_campaigns(message: Message):
    await message.answer(
        "🎯 *Активные кампании*\n\n"
        "🎯 *MrBeast*\n"
        "    ₽0.30 за 1 000 просмотров · 248 клиперов\n\n"
        "🎙 *Дудь*\n"
        "    ₽0.25 за 1 000 просмотров · 89 клиперов\n\n"
        "⚡ *Хасбулла*\n"
        "    ₽0.40 за 1 000 просмотров · 134 клипера\n\n"
        "👇 Выбери кампанию и загружай клипы!",
        reply_markup=btn("✂️ Загрузить клип")
    )


# ── /top ──────────────────────────────────────────────────
@dp.message(Command("top"))
async def cmd_top(message: Message):
    await message.answer(
        "🏆 *Топ клиперов этого месяца*\n\n"
        "🥇 *clip_king_95* — 4 820 ₽ · 32 клипа\n"
        "🥈 *видео_мастер* — 3 210 ₽ · 21 клип\n"
        "🥉 *ты* — 540 ₽ · 3 клипа\n"
        "4\\. *rusclips_pro* — 490 ₽ · 18 клипов\n"
        "5\\. *мега_клипер* — 310 ₽ · 9 клипов\n\n"
        "📍 Твоё место: *#3 из 14 200 клиперов*\n\n"
        "💪 До второго места осталось *2 670 ₽*",
        reply_markup=btn("🏆 Полный лидерборд")
    )


# ── /help ─────────────────────────────────────────────────
@dp.message(Command("help"))
async def cmd_help(message: Message):
    await message.answer(
        "📖 *Все команды КЛИПРУБЛЬ*\n\n"
        "/start — главное меню\n"
        "/balance — мой баланс и статистика\n"
        "/clips — мои последние клипы\n"
        "/campaigns — активные кампании\n"
        "/top — лидерборд месяца\n"
        "/help — эта справка\n\n"
        "💡 *Как заработать больше:*\n"
        "• Добавляй субтитры к клипам +40% просмотров\n"
        "• Первые 3 секунды — самое важное\n"
        "• MrBeast — самый вирусный контент\n\n"
        "👇 Открой приложение",
        reply_markup=btn()
    )


# ── Обработка обычных сообщений ───────────────────────────
@dp.message(F.text)
async def handle_text(message: Message):
    text = message.text.lower()

    # Если прислали ссылку на видео
    video_links = [
        "youtube.com/shorts",
        "youtube.com/watch",
        "youtu.be",
        "tiktok.com",
        "vk.com/video",
        "vk.com/clip"
    ]
    if any(link in text for link in video_links):
        await message.answer(
            "🔗 *Вижу ссылку на клип!*\n\n"
            "Отлично — загрузи её через приложение "
            "и начни зарабатывать 👇",
            reply_markup=btn("✂️ Загрузить этот клип")
        )
        return

    # Ответы на частые вопросы
    if any(w in text for w in ["сколько", "зарабат", "деньг", "платит"]):
        await message.answer(
            "💰 *Сколько можно заработать?*\n\n"
            "Зависит от просмотров и кампании:\n\n"
            "• MrBeast: ₽0.30 за 1 000 просмотров\n"
            "• 100к просмотров = ₽30\n"
            "• 1М просмотров = ₽300\n\n"
            "Топ клиперы зарабатывают *₽3 000–5 000 в месяц* "
            "загружая 2–3 клипа в неделю 🔥\n\n"
            "👇 Попробуй сам!",
            reply_markup=btn("✂️ Загрузить первый клип")
        )
        return

    if any(w in text for w in ["вывест", "вывод", "получ"]):
        await message.answer(
            "💸 *Как вывести деньги?*\n\n"
            "1. Накопи минимум *100 ₽*\n"
            "2. Открой раздел *Кошелёк*\n"
            "3. Выбери способ вывода:\n"
            "   💳 ЮMoney — мгновенно\n"
            "   📱 QIWI — до 1 дня\n"
            "   ₿ Крипто USDT — 1–2 дня\n\n"
            "👇 Открой кошелёк",
            reply_markup=btn("💰 Открыть кошелёк")
        )
        return

    if any(w in text for w in ["как", "начать", "помог", "что делать"]):
        await message.answer(
            "🚀 *Как начать зарабатывать?*\n\n"
            "1️⃣ Открой приложение\n"
            "2️⃣ Выбери кампанию блогера\n"
            "3️⃣ Найди крутое видео и нарежь клип 30–90 сек\n"
            "4️⃣ Загрузи ссылку\n"
            "5️⃣ Жди одобрения — до 24 часов\n"
            "6️⃣ Деньги начисляются автоматически!\n\n"
            "👇 Поехали!",
            reply_markup=btn("🚀 Открыть платформу")
        )
        return

    # По умолчанию
    await message.answer(
        f"Привет! 👋\n\n"
        f"Нажми кнопку чтобы открыть КЛИПРУБЛЬ 👇",
        reply_markup=btn()
    )


# ── Запуск ────────────────────────────────────────────────
async def on_startup():
    # Устанавливаем команды бота в меню
    await bot.set_my_commands([
        types.BotCommand(command="start",     description="🏠 Главное меню"),
        types.BotCommand(command="balance",   description="💰 Мой баланс"),
        types.BotCommand(command="clips",     description="✂️ Мои клипы"),
        types.BotCommand(command="campaigns", description="🎯 Активные кампании"),
        types.BotCommand(command="top",       description="🏆 Лидерборд"),
        types.BotCommand(command="help",      description="📖 Помощь"),
    ])
    log.info("✅ КЛИПРУБЛЬ бот запущен!")
    log.info(f"🌐 Web App URL: {APP_URL}")


async def main():
    dp.startup.register(on_startup)
    log.info("🚀 Запускаем бота...")
    await dp.start_polling(bot, skip_updates=True)


if __name__ == "__main__":
    asyncio.run(main())
